public class animal {
}
