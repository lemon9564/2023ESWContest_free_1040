import numpy as np
from transforms3d.euler import euler2mat

class SwingController:
    def __init__(self, config):
        self.config = config

    def raibert_touchdown_location(
        self, leg_index, command #leg_index = [0,1,2,3] , 
    ):
        delta_p_2d = (
            self.config.alpha # alpha = 0.5, 터치다운 거리와 총 수평 자세 움직임 사이의 비율
            * self.config.stance_ticks # stance_ticks = 45
            * self.config.dt # dt = 0.01
            * command.horizontal_velocity # horizontal_velocity = np.array([0, 0])
            #x_vel = msg["ly"] * self.config.max_x_velocity = 0.4
            #y_vel = msg["lx"] * -self.config.max_y_velocity = 0.3
            #command.horizontal_velocity = np.array([x_vel, y_vel])
        )
        delta_p = np.array([delta_p_2d[0], delta_p_2d[1], 0])
        theta = (
            self.config.beta # beta = 0.5
            * self.config.stance_ticks # stance_ticks = 45
            * self.config.dt # dt = 0.01
            * command.yaw_rate
            # command.yaw_rate = msg["rx"] * -self.config.max_yaw_rate = 2.0
        )
        R = euler2mat(0, 0, theta)
        return R @ self.config.default_stance[:, leg_index] + delta_p


    def swing_height(self, swing_phase, triangular=True):
        if triangular:
            if swing_phase < 0.5:
                swing_height_ = swing_phase / 0.5 * self.config.z_clearance #z_clearance = 0.07
            else:
                swing_height_ = self.config.z_clearance * (1 - (swing_phase - 0.5) / 0.5)
        return swing_height_


    def next_foot_location(
        self,
        swing_prop,
        leg_index,
        state,
        command,
    ):
        assert swing_prop >= 0 and swing_prop <= 1
        foot_location = state.foot_locations[:, leg_index]
        #print(foot_location)
        swing_height_ = self.swing_height(swing_prop)
        touchdown_location = self.raibert_touchdown_location(leg_index, command)
        time_left = self.config.dt * self.config.swing_ticks * (1.0 - swing_prop) # dt = 0.01, swing_ticks = 15 , 
        v = (touchdown_location - foot_location) / time_left * np.array([1, 1, 0])
        delta_foot_location = v * self.config.dt
        z_vector = np.array([0, 0, swing_height_ + command.height])
        #print('time_left =',time_left)
        #if leg_index == 0: print('foot_location(0) =',foot_location)
        #if leg_index == 2: print('foot_location(2) =',foot_location)
        #print('swing_height =',swing_height_)
        #if leg_index == 0: print('foot_location(0) =',foot_location)
        return foot_location * np.array([1, 1, 0]) + z_vector + delta_foot_location
