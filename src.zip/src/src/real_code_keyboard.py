import keyboard
import time


msg = {"R1":0,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}

ac_ro = True
class select:
    def __init__(self):
        self.msg = {"R1":0,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
        self.ac_ro = True
        self.gait_ro = True
    def select_condition(self):
        if keyboard.is_pressed('g'):   # 로봇 전진
            print("go")
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0.3,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
            time.sleep(0.1)
            return self.msg
            
        elif keyboard.is_pressed('b'): # 로봇 후진
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0,"lx":-0.3,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
            print("back")           
            time.sleep(0.1)
            return self.msg
        
        elif keyboard.is_pressed('u'): # 로봇 상승
            self.msg = {"R1":0,"x":1,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
            print("UP")           
            time.sleep(0.1)
            return self.msg
            
        elif keyboard.is_pressed('r'): # 로봇 포인트턴, 오른쪽
            print("point_right")
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0.3,"ry":0,"dpady":0,"dpadx":0}
            time.sleep(0.1)
            return self.msg
            
        elif keyboard.is_pressed('l'): # 로봇 포인트턴, 왼쪽
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":-0.3,"ry":0,"dpady":0,"dpadx":0}
            print("point_left")      
            time.sleep(0.1)
            return self.msg
            
        elif keyboard.is_pressed('1'): # 로봇 커브턴, 오른쪽
            print("curve_right")
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0.1,"lx":0,"message_rate":1.0,"rx":0.1,"ry":0,"dpady":0,"dpadx":0}
            time.sleep(0.1)
            return self.msg
            
        elif keyboard.is_pressed('2'): # 로봇 커브턴, 왼쪽
            print("curve_left")
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0.1,"lx":0,"message_rate":1.0,"rx":-0.1,"ry":0,"dpady":0,"dpadx":0}
            time.sleep(0.1)
            return self.msg
            
        elif keyboard.is_pressed('s'): # 로봇 정지
            print("stop") 
            self.msg = {"R1":0,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
            time.sleep(0.2)
            return self.msg
            
        elif keyboard.is_pressed('a'): #로봇 activate 토글
            if self.ac_ro == True:
                print("activate robot")
                self.msg = {"R1":0,"x":0,"L1":1,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
                self.ac_ro = False
                time.sleep(0.2)
                
            else: 
                print("deactivate robot")
                self.msg = {"R1":0,"x":0,"L1":1,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
                self.ac_ro = True
                time.sleep(0.2)
                
            time.sleep(0.1)
            return self.msg
        elif keyboard.is_pressed('q'): #로봇 activate 토글
            if self.gait_ro == True:
                print("gait robot")
                self.msg = {"R1":1,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
                self.gait_ro = False
                time.sleep(0.2)
                
            else: 
                print("degait robot")
                self.msg = {"R1":1,"x":0,"L1":0,"ly":0,"lx":0,"message_rate":1.0,"rx":0,"ry":0,"dpady":0,"dpadx":0}
                self.gait_ro = True
                time.sleep(0.2)
            time.sleep(0.1)
            return self.msg
        
        else:
            return self.msg
            time.sleep(0.1)
            pass
        