from src.real_code_keyboard import select

class Joy:
    def __init__(self):
        self.a = 1
    
    
    def get_command():
        print(1)
        '''
        b = select()
        msg = b.select_condition()
        print(11)
        print("msg=",msg)
        '''