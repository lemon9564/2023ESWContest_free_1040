
import numpy as np 
import time


class UpController:
    def __init__(self,height,wide):
        
        self.tick = 0
        self.foot = np.zeros((3,4))
        self.first_count = 0
        self.second_count = 0
        self.up_count = 0
        self.down_count = 0
        self.renew_tick = 8
        
        self.print = 0
        
        self.height = height
        self.wide = wide
        self.foot = np.zeros((3,4))
        self.default_position = [0.10, 0.08, 0.16]
        self.default = np.array([[1,1,-1,-1],
                                 [-1,1,-1,1],
                                 [-1,-1,-1,-1]])
        self.z_hi = -0.145
        for i in range(4):
            self.foot[:,i] = self.default[:,i]*self.default_position
        
        self.tick = 0
        self.count_1 = 0
        self.renew_tick = 3
        self.renew_tick_slow = 12

        self.flat = 0

        self.foot_0 = 0.105
        self.foot_1 = 0.105
        self.foot_2 = -0.105
        self.foot_3 = -0.105
        self.foot_3_2 = -0.095
        self.foot_3_3 = -0.095
        
        self.f1_pi = 0.2
        self.f2_pi = 0
        self.f3_pi = 0
        self.s1_pi = 0.2
        self.s2_pi = 0
        self.s3_pi = 0
        self.t1_pi = 0.2
        self.t2_pi = 0.2
        self.t3_pi = 0.13
        
        self.f1_rol = 0
        self.f2_rol = 0
        self.f3_rol = 0
        self.s1_rol = 0
        self.s2_rol = 0
        self.s3_rol = 0
        self.t1_rol = 0
        self.t2_rol = 0
        self.t3_rol = 0
        
        self.infi = 0
        
        self.pitch = 0
        self.roll = 0
        
        
        
        
        self.f_c_1_2 = 0.065 #1번다리 스탭전 무게중심 뒤로
        self.f_c_2_3 = 0.03 #2,3번다리 스탭전 무게중심 앞으로
        self.f_c_3_4 = self.f_c_1_2-self.f_c_2_3
        self.f_c_4_5 = 0 #4번다리 스텝전 무게중심 앞으로
        self.f_c_5_6 = self.f_c_3_4-self.f_c_4_5
        
        
        self.s_c_1_2 = 0.065
        self.s_c_0_1 = -self.f_c_5_6+self.s_c_1_2
        self.s_c_2_3 = 0.03
        self.s_c_3_4 = self.s_c_1_2-self.f_c_2_3
        self.s_c_4_5 = 0
        self.s_c_5_6 = self.s_c_3_4-self.s_c_4_5
        
        self.t_c_0_1 = 0.055
        self.t_c_1_2 = 0.06
        self.t_c_2_3 = 0.105
        self.t_c_3_4 = self.t_c_1_2-self.t_c_2_3
        self.t_c_4_5 = 0.038
        self.t_c_5_6 = self.t_c_3_4-self.t_c_4_5
        self.t_c_1_1 = -self.s_c_5_6+self.t_c_0_1
        self.t_c_2_2 = -self.t_c_5_6+self.t_c_0_1
        self.t_c_2_2_1 = 0.03     
        
                
    def x_front(self,ticks,in_x,leg_index=0):
        
        x_h_f = np.linspace(in_x,in_x+self.wide,16) #0.2 빼기
        self.foot[0,leg_index] = x_h_f[ticks]
        
        
        return self.foot
    
    def x_half_front(self,ticks,in_x,leg_index=0): #ticks 순서,in_x 초기 위치, wide 계단 폭, index=0 다리 번호
    
        x_h_f = np.linspace(in_x,in_x+self.wide/2,16)
        self.foot[0,leg_index] = x_h_f[ticks]
        
        
        return self.foot
        
    def x_back(self,ticks,in_x,leg_index=0):
        
        x_b = np.linspace(in_x,in_x-self.wide,16)
        self.foot[0,leg_index] = x_b[ticks]
        
        
        return self.foot
    
    
    def x_half_back(self,ticks,in_x,leg_index=0):
        
        x_h_b = np.linspace(in_x,in_x-self.wide/2,16)
        self.foot[0,leg_index] = x_h_b[ticks]
        
        
        return self.foot
    
    
    
    def x_center_front(self,ticks,in_x,how_x,leg_index=0):
        
        x_c_b = np.linspace(in_x,in_x-how_x,16)
        self.foot[0,leg_index] = x_c_b[ticks]
        
        return self.foot
        
    def x_center_back(self,ticks,in_x,how_x,leg_index=0):
        
        x_c_f = np.linspace(in_x,in_x+how_x,16)
        self.foot[0,leg_index] = x_c_f[ticks]
        
        return self.foot
    
    def z_up(self,ticks,in_z,leg_index=0):
        
        z_upper = np.linspace(in_z,in_z+0.12,3)
        z_dow = np.linspace(in_z+0.12,in_z+self.height,13)
        z = np.concatenate((z_upper,z_dow))
        self.foot[2,leg_index] = z[ticks]
        
        
        return self.foot
    
    def z_half_up(self,ticks,in_z,leg_index=0):
        
        z_h_upper = np.linspace(in_z,in_z+0.12,8)
        z_h_dow = np.linspace(in_z+0.12,in_z+self.height/2,8)
        z_h = np.concatenate((z_h_upper,z_h_dow))
    
        self.foot[2,leg_index] = z_h[ticks]
        
        return self.foot
    
    def z_down(self,ticks,in_z,leg_index=0):
        
        z_d = np.linspace(in_z,in_z-self.height,16)
        self.foot[2,leg_index] = z_d[ticks]
        
        
        return self.foot  
    
    
    def z_half_down(self,ticks,in_z,leg_index=0):
        
        z_h_d = np.linspace(in_z,in_z-self.height/2,16)
        self.foot[2,leg_index] = z_h_d[ticks]
        
        
        return self.foot

    def z_half_down2(self,ticks,in_z,leg_index=0):
       z_h_u2 = np.linspace(in_z,in_z+0.03,8)
       z_h_d2 = np.linspace(in_z+0.03, in_z-self.height/2,8)
       z_h = np.concatenate((z_h_u2,z_h_d2))
       self.foot[2,leg_index] = z_h[ticks]

       return self.foot
    
###########################
    

    def first_1(self,t): #1번다리
        #print(t)
        if self.print:
            print("first_1")
        
        self.pitch = slow_body(0,self.f1_pi,t)
        self.roll = slow_body(0,self.f1_rol,t)
        self.foot = self.x_center_back(t,self.foot_0,self.f_c_1_2,leg_index=0) #0.12
        self.foot = self.x_center_back(t,self.foot_1,self.f_c_1_2,leg_index=1) #0.12
        self.foot = self.x_center_back(t,self.foot_2,self.f_c_1_2,leg_index=2) #-0.08
        self.foot = self.x_center_back(t,self.foot_3,self.f_c_1_2,leg_index=3) #-0.08
        time.sleep(0.01)
        
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 1
                time.sleep(0.5)
        
        
        return self.foot

    def first_2(self,t):
        
        #print(t)
        if self.print:
            print("first_2")
        
        
        
        self.foot = self.x_front(t,self.foot_0+self.f_c_1_2,leg_index=0) #0.12+self.wide
        self.foot = self.z_up(t,self.z_hi,leg_index=0) #-0.16+self.height
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 2
                time.sleep(0.7)
        
        
        return self.foot
    
    def first_3(self,t): #2번다리,3번다리
    
        if self.print:
            print("first_3")
        
        self.pitch = slow_body(self.f1_pi,self.f2_pi,t)
        self.roll = slow_body(self.f1_rol,self.f2_rol,t)
        self.foot = self.x_center_front(t,self.foot_0+self.f_c_1_2+self.wide,self.f_c_2_3,leg_index=0) #0.10
        self.foot = self.x_center_front(t,self.foot_1+self.f_c_1_2,self.f_c_2_3,leg_index=1) #0.10
        self.foot = self.x_center_front(t,self.foot_2+self.f_c_1_2,self.f_c_2_3,leg_index=2) #-0.10
        self.foot = self.x_center_front(t,self.foot_3+self.f_c_1_2,self.f_c_2_3,leg_index=3) #-0.10
        time.sleep(0.005)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 3
                time.sleep(0.7)
        
        
        return self.foot

        
    def first_4(self,t):
        
        if self.print:
            print("first_4")
        
        
        self.foot = self.x_half_back(t,self.foot_0+self.f_c_3_4+self.wide,leg_index=0)
        self.foot = self.z_half_down(t,self.z_hi+self.height,leg_index=0)
        
        self.foot = self.x_half_front(t,self.foot_1+self.f_c_3_4,leg_index=1)
        self.foot = self.z_half_up(t,self.z_hi,leg_index=1)
        
        self.foot = self.x_half_front(t,self.foot_2+self.f_c_3_4,leg_index=2)
        self.foot = self.z_half_down(t,self.z_hi,leg_index=2)
        
        self.foot = self.x_half_back(t,self.foot_3+self.f_c_3_4,leg_index=3)
        self.foot = self.z_half_down(t,self.z_hi,leg_index=3)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 4
                time.sleep(0.7)
        
        
        return self.foot


    def first_5(self,t):
        
        if self.print:
            print("first_5")
        
        self.pitch = slow_body(self.f2_pi,self.f3_pi,t)
        self.roll = slow_body(self.f2_rol,self.f3_rol,t)
        
        
        self.foot = self.x_center_front(t,self.foot_0+self.f_c_3_4+(self.wide/2),self.f_c_4_5,leg_index=0) #0.08
        self.foot = self.x_center_front(t,self.foot_1+self.f_c_3_4+(self.wide/2),self.f_c_4_5,leg_index=1) #0.08
        self.foot = self.x_center_front(t,self.foot_2+self.f_c_3_4+(self.wide/2),self.f_c_4_5,leg_index=2) #-0.12
        self.foot = self.x_center_front(t,self.foot_3+self.f_c_3_4-(self.wide/2),self.f_c_4_5,leg_index=3) #-0.12
        time.sleep(0.005)
        
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 5
                time.sleep(0.7)
        
        
        return self.foot

    
    
    def first_6(self,t):
        
        if self.print:
            print("first_6")
        
        self.foot = self.x_half_back(t,self.foot_0+self.f_c_5_6+(self.wide/2),leg_index=0)
        self.foot = self.z_half_down(t,self.z_hi+(self.height/2),leg_index=0)
        
        self.foot = self.x_half_back(t,self.foot_1+self.f_c_5_6+(self.wide/2),leg_index=1)
        self.foot = self.z_half_down(t,self.z_hi+(self.height/2),leg_index=1)
        
        self.foot = self.x_half_back(t,self.foot_2+self.f_c_5_6+(self.wide/2),leg_index=2)
        self.foot = self.z_half_down(t,self.z_hi-(self.height/2),leg_index=2)
        
        self.foot = self.x_half_front(t,self.foot_3+self.f_c_5_6-(self.wide/2),leg_index=3)
        self.foot = self.z_half_down(t,self.z_hi-(self.height/2),leg_index=3)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 6
                time.sleep(0.6)
        
        
        return self.foot
    
    def second_1(self,t):
        
        if self.print:
            print("second_1")
        
        self.pitch = slow_body(self.f3_pi,self.s1_pi,t)
        self.roll = slow_body(self.f3_rol,self.s1_rol,t)
        self.foot = self.x_center_back(t,self.foot_0+self.f_c_5_6,self.s_c_0_1,leg_index=0) #0.12
        self.foot = self.x_center_back(t,self.foot_1+self.f_c_5_6,self.s_c_0_1,leg_index=1) #0.12
        self.foot = self.x_center_back(t,self.foot_2+self.f_c_5_6,self.s_c_0_1,leg_index=2) #-0.08
        self.foot = self.x_center_back(t,self.foot_3+self.f_c_5_6,self.s_c_0_1,leg_index=3) #-0.08
        time.sleep(0.005)
        
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 7
                time.sleep(0.6)
        
        return self.foot
    
    def second_2(self,t):
        
        if self.print:
            print("second_2")
        
        self.foot = self.x_front(t,self.foot_0+self.s_c_1_2,leg_index=0)
        self.foot = self.z_up(t,self.z_hi,leg_index=0)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 8
                time.sleep(0.6)
        
        return self.foot
    
    def second_3(self,t):
        
        if self.print:
            print("second_3")
            
        self.pitch = slow_body(self.s1_pi,self.s2_pi,t)
        self.roll = slow_body(self.s1_rol,self.s2_rol,t)
        self.foot = self.x_center_front(t,self.foot_0+self.s_c_1_2+self.wide,self.s_c_2_3,leg_index=0) #0.10
        self.foot = self.x_center_front(t,self.foot_1+self.s_c_1_2,self.s_c_2_3,leg_index=1) #0.10
        self.foot = self.x_center_front(t,self.foot_2+self.s_c_1_2,self.s_c_2_3,leg_index=2) #-0.10
        self.foot = self.x_center_front(t,self.foot_3+self.s_c_1_2,self.s_c_2_3,leg_index=3) #-0.10
        time.sleep(0.005)
        
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 9
                time.sleep(0.7)
        return self.foot
    
    def second_4(self,t):
        
        if self.print:
            print("second_4")
        
        self.foot = self.x_half_back(t,self.foot_0+self.s_c_3_4+self.wide,leg_index=0)
        self.foot = self.z_half_down(t,self.z_hi+self.height,leg_index=0)
        
        self.foot = self.x_half_front(t,self.foot_1+self.s_c_3_4,leg_index=1)
        self.foot = self.z_half_up(t,self.z_hi,leg_index=1)
        
        self.foot = self.x_half_front(t,self.foot_2+self.s_c_3_4,leg_index=2)
        self.foot = self.z_half_down(t,self.z_hi-self.height,leg_index=2)
        
        self.foot = self.x_half_back(t,self.foot_3+self.s_c_3_4,leg_index=3)
        self.foot = self.z_half_down(t,self.z_hi-(self.height),leg_index=3)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 10
                time.sleep(0.7)
        
        
        return self.foot
    
    def second_5(self,t):
        
        if self.print:
            print("second_5")
        
        self.pitch = slow_body(self.s2_pi,self.s3_pi,t)
        self.roll = slow_body(self.s2_rol,self.s3_rol,t)
        time.sleep(0.005)
        
        self.foot = self.x_center_front(t,self.foot_0+self.s_c_3_4+(self.wide/2),self.s_c_4_5,leg_index=0) #0.08
        self.foot = self.x_center_front(t,self.foot_1+self.s_c_3_4+(self.wide/2),self.s_c_4_5,leg_index=1) #0.08
        self.foot = self.x_center_front(t,self.foot_2+self.s_c_3_4+(self.wide/2),self.s_c_4_5,leg_index=2) #-0.12
        self.foot = self.x_center_front(t,self.foot_3+self.s_c_3_4-(self.wide/2),self.s_c_4_5,leg_index=3) #-0.12
        
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 11
                time.sleep(0.7)
        return self.foot
    
    def second_6(self,t):
        
        if self.print:
            print("second_6")
        
        self.foot = self.x_half_back(t,self.foot_0+self.s_c_5_6+(self.wide/2),leg_index=0)
        self.foot = self.z_half_down(t,self.z_hi+(self.height/2),leg_index=0)
        
        self.foot = self.x_half_back(t,self.foot_1+self.s_c_5_6+(self.wide/2),leg_index=1)
        self.foot = self.z_half_down(t,self.z_hi+(self.height/2),leg_index=1)
        
        self.foot = self.x_half_back(t,self.foot_2+self.s_c_5_6+(self.wide/2),leg_index=2)
        self.foot = self.z_half_down(t,self.z_hi-self.height-(self.height/2),leg_index=2)
        
        self.foot = self.x_half_front(t,self.foot_3+self.s_c_5_6-(self.wide/2),leg_index=3)
        self.foot = self.z_half_down(t,self.z_hi-(self.height)-(self.height/2),leg_index=3)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 12
                time.sleep(0.7)
        
        
        return self.foot
    
    def third_1(self,t):
        
        if self.print:
            print("third_1")
            
        if self.infi == 0:
            self.pitch = slow_body(self.s3_pi,self.t1_pi,t)
            self.roll = slow_body(self.s3_rol,self.t1_rol,t)
            self.foot = self.x_center_back(t,self.foot_0+self.s_c_5_6,self.t_c_1_1,leg_index=0) #0.12
            self.foot = self.x_center_back(t,self.foot_1+self.s_c_5_6,self.t_c_1_1,leg_index=1) #0.12
            self.foot = self.x_center_back(t,self.foot_3_2+self.s_c_5_6,self.t_c_1_1,leg_index=2) #-0.08
            self.foot = self.x_center_back(t,self.foot_3_3+self.s_c_5_6,self.t_c_1_1,leg_index=3) #-0.08
            time.sleep(0.02)
        elif self.infi == 1:
            self.pitch = slow_body(self.t3_pi,self.t1_pi,t)
            self.roll = slow_body(self.t3_rol,self.t1_rol,t)
            self.foot = self.x_center_back(t,self.foot_0+self.t_c_5_6,self.t_c_2_2-self.t_c_2_2_1,leg_index=0) #0.12
            self.foot = self.x_center_back(t,self.foot_1+self.t_c_5_6,self.t_c_2_2-self.t_c_2_2_1,leg_index=1) #0.12
            self.foot = self.x_center_back(t,self.foot_3_2+self.t_c_5_6,self.t_c_2_2-self.t_c_2_2_1,leg_index=2) #-0.08
            self.foot = self.x_center_back(t,self.foot_3_3+self.t_c_5_6,self.t_c_2_2-self.t_c_2_2_1,leg_index=3) #-0.08
            time.sleep(0.02)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 13
                time.sleep(0.8)
        
        
        return self.foot
    
    
    def third_2(self,t):
        
        if self.print:
            print("third_2")
        
        self.foot = self.x_front(t,self.foot_0+self.t_c_1_2,leg_index=0)
        self.foot = self.z_up(t,self.z_hi,leg_index=0)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 14
                time.sleep(0.8)
        
        
        return self.foot
    
    def third_3(self,t):
        
        if self.print:
            print("third_3")
        
        self.pitch = slow_body(self.t1_pi,self.t2_pi,t)
        self.roll = slow_body(self.t1_rol,self.t2_rol,t)
        self.foot = self.x_center_front(t,self.foot_0+self.t_c_1_2+self.wide,self.t_c_2_3,leg_index=0) #0.10
        self.foot = self.x_center_front(t,self.foot_1+self.t_c_1_2,self.t_c_2_3,leg_index=1) #0.10
        self.foot = self.x_center_front(t,self.foot_3_2+self.t_c_1_2,self.t_c_2_3,leg_index=2) #-0.10
        self.foot = self.x_center_front(t,self.foot_3_3+self.t_c_1_2,self.t_c_2_3,leg_index=3) #-0.10
        time.sleep(0.005)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 15
                time.sleep(0.8)
        
        
        return self.foot
    
    def third_4(self,t):
        
        #print(t)
        if self.print:
            print("third_4")
        
        
        
        self.foot = self.x_half_back(t,self.foot_0+self.wide+(self.t_c_3_4),leg_index=0)
        self.foot = self.z_half_down(t,self.z_hi+self.height,leg_index=0)
        
        self.foot = self.x_half_front(t,self.foot_1+(self.t_c_3_4),leg_index=1)
        self.foot = self.z_half_up(t,self.z_hi,leg_index=1)
        
        self.foot = self.x_half_front(t,self.foot_3+(self.t_c_3_4),leg_index=2)
        self.foot = self.z_half_up(t,self.z_hi-(2*self.height),leg_index=2)
        
        self.foot = self.x_half_back(t,self.foot_3+(self.t_c_3_4),leg_index=3)
        self.foot = self.z_half_down(t,self.z_hi-(2*self.height),leg_index=3)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 16
                time.sleep(0.8)
        
        
        return self.foot
    
    def third_5(self,t):
        
        if self.print:
            print("third_5")
        
        self.pitch = slow_body(self.t2_pi,self.t3_pi,t)
        self.roll = slow_body(self.t2_rol,self.t3_rol,t)
        
        self.foot = self.x_center_front(t,self.foot_0+(self.t_c_3_4)+(self.wide/2),self.t_c_4_5,leg_index=0) #0.08
        self.foot = self.x_center_front(t,self.foot_1+(self.t_c_3_4)+(self.wide/2),self.t_c_4_5,leg_index=1) #0.08
        self.foot = self.x_center_front(t,self.foot_3_2+(self.t_c_3_4)+(self.wide/2),self.t_c_4_5,leg_index=2) #-0.12
        self.foot = self.x_center_front(t,self.foot_3_3+(self.t_c_3_4)-(self.wide/2),self.t_c_4_5,leg_index=3) #-0.12
        time.sleep(0.005)
        if t==15:
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 17
                time.sleep(0.8)
        
        
        return self.foot
    
    
    def third_6(self,t):
        #print(t)
        if self.print:
            print("third_6")
        
        
        
        self.foot = self.x_half_back(t,self.foot_0+self.t_c_5_6+(self.wide/2),leg_index=0)
        self.foot = self.z_half_down(t,self.z_hi+(self.height/2),leg_index=0)
        
        self.foot = self.x_half_back(t,self.foot_1+self.t_c_5_6+(self.wide/2),leg_index=1)
        self.foot = self.z_half_down(t,self.z_hi+(self.height/2),leg_index=1)
        
        self.foot = self.x_half_back(t,self.foot_3_2+self.t_c_5_6+(self.wide/2),leg_index=2)
        self.foot = self.z_half_down(t,self.z_hi-(1.5*self.height),leg_index=2)
        
        self.foot = self.x_half_front(t,self.foot_3_3+self.t_c_5_6-(self.wide/2),leg_index=3)
        self.foot = self.z_half_up(t,self.z_hi-(2.5*self.height),leg_index=3)
        if t==15:
            self.infi = 1
            self.count_1 += 1
            if self.count_1 == self.renew_tick:
                self.count_1 = 0
                
                self.tick = 12
                time.sleep(0.3)
        
        
        return self.foot
    
    
    
    
    def vs_dis(self):
        
        return 0
    
    def sequence(self):
        if self.tick == 1:
            return 1
        elif self.tick == 2:
            return 2
        elif self.tick == 3:
            return 3
        elif self.tick == 4:
            return 4
        elif self.tick == 5:
            return 5
        elif self.tick == 6:
            return 6
        elif self.tick == 7:
            return 7
        elif self.tick == 8:
            return 8
        elif self.tick == 9:
            return 9
        elif self.tick == 10:
            return 10
        elif self.tick == 11:
            return 11
        elif self.tick == 12:
            return 12
        elif self.tick == 13:
            return 13
        elif self.tick == 14:
            return 14
        elif self.tick == 15:
            return 15
        elif self.tick == 16:
            return 16
        elif self.tick == 17:
            return 17
        elif self.tick == 18:
            return 18
        
        return 0
    
    
def slow_body(a,b,t):
    return (b-a)*t/15+a
