from src.Gaits import GaitController
from src.Up import UP_ticks
from src.StanceController import StanceController
from src.SwingLegController import SwingController
from src.UPController import UpController

from src.Utilities import clipped_first_order_filter
from src.State import BehaviorState, State

import numpy as np
from transforms3d.euler import euler2mat, quat2euler
from transforms3d.quaternions import qconjugate, quat2axangle
from transforms3d.axangles import axangle2mat
import time

class Controller:
    """Controller and planner object
    """

    def __init__(
        self,
        config,
        inverse_kinematics,
    ):
        self.config = config

        self.smoothed_yaw = 0.0  # for REST mode only
        self.inverse_kinematics = inverse_kinematics

        self.contact_modes = np.zeros(4)
        self.gait_controller = GaitController(self.config)
        self.swing_controller = SwingController(self.config)
        self.stance_controller = StanceController(self.config)
        self.up_ticks = UP_ticks(self.config)
        self.up_controller = UpController(0.04,0.103)

        #self.hop_transition_mapping = {BehaviorState.REST: BehaviorState.HOP, BehaviorState.HOP: BehaviorState.FINISHHOP, BehaviorState.FINISHHOP: BehaviorState.REST, BehaviorState.TROT: BehaviorState.HOP}
        self.trot_transition_mapping = {BehaviorState.REST: BehaviorState.TROT, BehaviorState.TROT: BehaviorState.REST}
        self.activate_transition_mapping = {BehaviorState.DEACTIVATED: BehaviorState.REST, BehaviorState.REST: BehaviorState.DEACTIVATED}
        self.up_transition_mapping = {BehaviorState.REST: BehaviorState.UP, BehaviorState.UP: BehaviorState.REST}
        #self.up_transition_mapping = {BehaviorState.REST: BehaviorState.TROT}
        self.ne_foot_location = np.zeros((3,4))
        self.sequence = 0
        self.tick_order = 0
        self.normal_location = np.array([[0.10765, 0.10765, -0.10765, -0.10765],
                                         [-0.0715, 0.0715,   -0.0715,   0.0715],
                                         [-0.16,    -0.16,     -0.16,    -0.16]])
        
    
    
    
    def ticks_slow(self, ticks):
        tickk = ticks//4
        


    def step_gait(self, state, command):
        """Calculate the desired foot locations for the next timestep

        Returns
        -------
        Numpy array (3, 4)
            Matrix of new foot locations.
        """
        contact_modes = self.gait_controller.contacts(state.ticks) #[1 1 1 1],[1 0 0 1],[1 1 1 1],[0 1 1 0] 순으로 출력
        new_foot_locations = np.zeros((3, 4))
        for leg_index in range(4):
            #print(contact_modes)
            contact_mode = contact_modes[leg_index]
            foot_location = state.foot_locations[:, leg_index] #차원 변환
            if contact_mode == 1: #1,0,1,0 반복중 1일때 로봇 발4개가 모두 땅에 착지상태
                new_location = self.stance_controller.next_foot_location(leg_index, state, command)
            else: #1,0,1,0 반복중 0일때이며 로봇 발 4개중 2개가 움직이고 있을때
                swing_proportion = (
                    self.gait_controller.subphase_ticks(state.ticks) / self.config.swing_ticks #swing_ticks = 15
                )
                new_location = self.swing_controller.next_foot_location(
                    swing_proportion,
                    leg_index,
                    state,
                    command,
                ) #발 위치를 계속 최신화 시킴
            new_foot_locations[:, leg_index] = new_location # 저장
        return new_foot_locations, contact_modes #리턴 
    def step_up(self, state):
        
        
        renew = self.up_controller.renew_tick
        tickk = state.ticks//renew
        re_tickk = tickk%16 #0~15
        #print('self.up_controller.sequence()=',self.up_controller.sequence())
        if self.up_controller.sequence() == 0:
            if self.tick_order == 0:
                if re_tickk != 0:
                    print("in")
                    new_foot_locations = self.normal_location
                    return new_foot_locations
                elif re_tickk == 0:
                    print("out")
                    self.tick_order = 1
            
            if self.tick_order == 1:
                new_foot_locations = self.up_controller.first_1(re_tickk)
                return new_foot_locations
        
                
            
            
            
            
        elif self.up_controller.sequence() == 1:    
            
            new_foot_locations = self.up_controller.first_2(re_tickk)
            return new_foot_locations
            
        elif self.up_controller.sequence() == 2:
            
            new_foot_locations = self.up_controller.first_3(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 3:
            
            new_foot_locations = self.up_controller.first_4(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 4:
            
            new_foot_locations = self.up_controller.first_5(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 5:
            
            new_foot_locations = self.up_controller.first_6(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 6:
            
            new_foot_locations = self.up_controller.second_1(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 7:
            
            new_foot_locations = self.up_controller.second_2(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 8:
            
            new_foot_locations = self.up_controller.second_3(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 9:
            
            new_foot_locations = self.up_controller.second_4(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 10:
            
            new_foot_locations = self.up_controller.second_5(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 11:
            
            new_foot_locations = self.up_controller.second_6(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 12:
            
            new_foot_locations = self.up_controller.third_1(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 13:
            
            new_foot_locations = self.up_controller.third_2(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 14:
            
            new_foot_locations = self.up_controller.third_3(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 15:
            
            new_foot_locations = self.up_controller.third_4(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 16:
            
            new_foot_locations = self.up_controller.third_5(re_tickk)
            return new_foot_locations
        
        elif self.up_controller.sequence() == 17:
            
            new_foot_locations = self.up_controller.third_6(re_tickk)
            return new_foot_locations
        

        


    def run(self, state, command):
        """Steps the controller forward one timestep

        Parameters
        ----------
        controller : Controller
            Robot controller object.
        """
        
        ########## Update operating state based on command ######
        if command.activate_event:
            state.behavior_state = self.activate_transition_mapping[state.behavior_state]
        elif command.trot_event:
            state.behavior_state = self.trot_transition_mapping[state.behavior_state]
        #elif command.hop_event:
            #state.behavior_state = self.hop_transition_mapping[state.behavior_state]
        elif command.up_event:
            #print("IN")
            #print(self.up_transition_mapping[state.behavior_state])
            state.behavior_state =  self.up_transition_mapping[state.behavior_state]
        
            
        #print(command.up_event)
        #print(state.behavior_state)

            
        if state.behavior_state == BehaviorState.TROT:
            state.foot_locations, contact_modes = self.step_gait(
                state,
                command,
            )
            #print(state.joint_angles)

            # Apply the desired body rotation
            rotated_foot_locations = (
                euler2mat(
                    command.roll, command.pitch, 0.0
                )
                @ state.foot_locations
            )
            #print("command:",command.pitch)

            # Construct foot rotation matrix to compensate for body tilt
            (roll, pitch, yaw) = quat2euler(state.quat_orientation)
            correction_factor = 0.8
            max_tilt = 0.4
            roll_compensation = correction_factor * np.clip(roll, -max_tilt, max_tilt)
            pitch_compensation = correction_factor * np.clip(pitch, -max_tilt, max_tilt)
            rmat = euler2mat(roll_compensation, pitch_compensation, 0)
            #print("rotatae_before = ", rotated_foot_locations)

            rotated_foot_locations = rmat.T @ rotated_foot_locations
            #print("rotatae_after = ", rotated_foot_locations)

            state.joint_angles = self.inverse_kinematics(
                rotated_foot_locations, self.config
            )
            

        

        elif state.behavior_state == BehaviorState.REST:
            yaw_proportion = command.yaw_rate / self.config.max_yaw_rate
            self.smoothed_yaw += (
                self.config.dt
                * clipped_first_order_filter(
                    self.smoothed_yaw,
                    yaw_proportion * -self.config.max_stance_yaw,
                    self.config.max_stance_yaw_rate,
                    self.config.yaw_time_constant,
                )
            )
            # Set the foot locations to the default stance plus the standard height
            state.foot_locations = (
                self.config.default_stance
                + np.array([0, 0, command.height])[:, np.newaxis]
            )
            #print(state.foot_locations)
            # Apply the desired body rotation
            rotated_foot_locations = (
                euler2mat(
                    command.roll,
                    command.pitch,
                    self.smoothed_yaw,
                )
                @ state.foot_locations
            )
            state.joint_angles = self.inverse_kinematics(
                rotated_foot_locations, self.config
            )
        
############################## UP ######################################
        
        elif state.behavior_state == BehaviorState.UP:
            #print("UP")
            
            #self.step_up(state)
            
            
            state.foot_locations = self.step_up(state)
            #print(state.foot_locations)
            
            
            
            rotated_foot_locations = (
                euler2mat(
                    self.up_controller.roll, self.up_controller.pitch, 0.0
                )
                @ state.foot_locations
            )
            
            state.joint_angles = self.inverse_kinematics(
                rotated_foot_locations, self.config
            )
            # print("4번째 다리 좌표 : ",state.foot_locations[:,3])
            
            
            
            
            
            
            
            
################################ END ################################# 
            
        state.ticks += 1
        state.pitch = command.pitch
        state.roll = command.roll
        state.height = command.height
        #print('state.ticks=',state.ticks)
        #self.ne_foot_location = rotated_foot_locations
        #print(rotated_foot_locations)
        #time.sleep(0.025)
        #print(state.foot_locations[:,3])
    def set_pose_to_default(self,state,controller):
        state.foot_locations = (
            self.config.default_stance
            + np.array([0, 0, self.config.default_z_ref])[:, np.newaxis]
        )
        state.joint_angles = np.clip(state.joint_angles, 0, 180)
        state.joint_angles = controller.inverse_kinematics(
            state.foot_locations, self.config
        )
        state.joint_angles = self.convert_to_positive_angles(state.joint_angles)

    def convert_to_positive_angles(self, state):
    # 각 관절 각도에 대해 양수로 변환
        positive_joint_angles = state.joint_angles % (2 * np.pi)
        return positive_joint_angles
        
