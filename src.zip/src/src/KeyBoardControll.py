

class KeyboardControll:
    def __init__(self):
        self.msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0.0 ,
                    'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                    'x' : False, 'triangle' : False, 'message_rate' : 20
                    }
        
        self.A_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0.0 ,
                    'R1' : False, 'L1' : True, 'dpady' : 0 , 'dpadx' : 0,
                    'x' : False, 'triangle' : False, 'message_rate' : 20
                    }
        
        self.D_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0.0 ,
                    'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                    'x' : False, 'triangle' : False, 'message_rate' : 20
                    }
        
        #M_msg = {ly:0.0,lx:0.0,rx:0.0,ry:0.0,R1:True,L1:False\n}
        self.M_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0 ,
                      'R1' : True, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : False, 'triangle' : False, 'message_rate' : 20
                      }
        
        #S_msg = "ly:0.0,lx:0.0,rx:0.0,ry:0.0,R1:False,L1:False\n"
        self.S_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : -0.1 ,
                      'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : False, 'triangle' : False, 'message_rate' : 20
                      }
        #L_msg = "ly:0.07450,lx:-0.39607,rx:0.0,ry:0.0,R1:False,L1:False\n"
        self.L_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : -0.25 , 'ry' : 0.0 ,
                      'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : False, 'triangle' : False, 'message_rate' : 20
                      }
        
        #R_msg = "ly:0.03529,lx:0.27405,rx:0.0,ry:0.0,R1:False,L1:False\n"
        self.R_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.25 , 'ry' : 0.0 ,
                      'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : False, 'triangle' : False, 'message_rate' : 20
                      }
        
        #F_msg = "ly:0.32549,lx:-0.07450,rx:-0.32549,ry:-0.04313,R1:False,L1:False\n"
        self.F_msg = {'ly' : 0.7 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0.0 ,
                      'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : False, 'triangle' : False, 'message_rate' : 20
                      }
        
        #B_msg = "ly:-0.3,lx:0.0,rx:0.0,ry:0.0,R1:Fasle,L1:False\n"
        self.B_msg = {'ly' : -0.4 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0.15 ,
                      'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : False, 'triangle' : False, 'message_rate' : 20
                      }
        
        self.U_msg = {'ly' : 0.0 , 'lx' : 0.0 , 'rx' : 0.0 , 'ry' : 0.0 ,
                      'R1' : False, 'L1' : False, 'dpady' : 0 , 'dpadx' : 0,
                      'x' : True, 'triangle' : False, 'message_rate' : 20
                      }
        
    def getData(self, data = 'a') :
        
        if data == 'a':
            self.msg = self.A_msg
            
        elif data == 'd':
            self.msg = self.D_msg
            
        elif data == 'm':
            self.msg = self.M_msg
            
        elif data == 's':
            self.msg = self.S_msg
        
        elif data == 'l':
            self.msg = self.L_msg
            
        elif data == 'r':
            self.msg = self.R_msg
            
        elif data == 'f':
            self.msg = self.F_msg
            
        elif data == 'b':
            self.msg = self.B_msg
            
        elif data == 'u':
            self.msg = self.U_msg
        
                            
        return self.msg
        
    

    
    
