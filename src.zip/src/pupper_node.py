#!/usr/bin/env python3
import numpy as np
import time
from src.IMU import IMU
from src.Controller import Controller
from src.JoystickInterface import JoystickInterface
from src.State import State
from pupper.HardwareInterface import HardwareInterface
from pupper.Config import Configuration
from pupper.Kinematics import four_legs_inverse_kinematics
from src.KeyBoardControll import KeyboardControll

import threading
import rospy
from geometry_msgs.msg import Twist
'''
import bluetooth
socket = bluetooth.BluetoothSocket( bluetooth.RFCOMM) 
socket.connect(("98:D3:31:FD:72:8A", 1))
print("bluetooth connected !")
'''
K = KeyboardControll()
Command = K.M_msg
lin = 0
ang = 0

def callback(data):
    global Command
    #rospy.loginfo(rospy.get_caller_id() + "speed: %s", data.data[0])

    global lin
    global ang
    
    lin = data.linear.x
    ang = data.angular.z
    '''
    if lin == 0:   #center
        msg = '2'
        socket.send(msg)
        
    elif lin > 0:  #GO
        msg = '1'
        socket.send(msg)
       
        if ang > 0:
            msg = '3'
        elif ang < 0:
            msg = '4'
        
        socket.send(msg)
            
    elif lin < 0:  # back
        msg = '5'
        socket.send(msg)

        if ang > 0:       
            msg = '3'
        elif ang < 0:
            msg = '4'
           
        socket.send(msg)
            
    msg = '0'
    socket.send(msg)
    '''
    comly = 7.8*lin    
    if(lin != 0.0):
        
        if(comly > 1.0):
            comly = 7.8*lin
        
        elif(comly <-1.0): #elif
            comly = 7.8*lin
    else:
        comly = 0.0

    Command['ly'] = comly
    
    if(ang != 0.0):
        Command['rx'] = -0.717*ang #0.72
    else:
        Command['rx'] = 0.0

def handler(use_imu=False):
    #rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data.data)
    
    # Create config
    config = Configuration()
    hardware_interface = HardwareInterface()
    # Create imu handle
    if use_imu:
        imu = IMU(port="/dev/ttyACM0")
        imu.flush_buffer()
    # Create controller and user input handles
    controller = Controller(
        config,
        four_legs_inverse_kinematics,
    )
    state = State()
    joystick_interface = JoystickInterface(config)
    last_loop = time.time()
    
    # Wait until the activate button has been pressed
    while True:
        time.sleep(0.1)
        print("Robot activated.")
        joystick_interface.set_color(config.ps4_color)
        pupper_time = time.time()

        while True:
            now = time.time()
            if now - last_loop < config.dt:
                continue
            last_loop = time.time()
            
            if time.time() - pupper_time < 5.0:
                command = joystick_interface.get_command(state, Com = K.msg)
            else:
                command = joystick_interface.get_command(state, Com = Command)
                
            quat_orientation = (
                    imu.read_orientation() if use_imu else np.array([1, 0, 0, 0])
                    )
            state.quat_orientation = quat_orientation
            # Step the controller forward by dt
            controller.run(state, command)
            # Update the pwm widths going to the servos
            hardware_interface.set_actuator_postions(state.joint_angles)
            
'''
cThread = threading.Thread(target=handler, args=(False,))
cThread.daemon = True
cThread.start()
'''

def listener():
    rospy.init_node('pupper_node', anonymous=True)
    rospy.Subscriber('cmd_vel', Twist, callback)
    rospy.spin()

if __name__ == '__main__':
    
    cThread = threading.Thread(target=handler, args=(False,))
    cThread.daemon = True
    cThread.start()
    listener()
    
    #except:
	#pass
        #socket.close()

