from adafruit_servokit import ServoKit
from pupper.Config import ServoParams

class HardwareInterface:
    def __init__(self):
        self.pi = ServoKit(channels=16)
        a = [0, 2, 3, 4, 6, 8, 9, 10]
        b = [1, 5, 7, 11]
        for i in a:
            self.pi.servo[i].set_pulse_width_range(2000, 1000)
        for i in b:
            self.pi.servo[i].set_pulse_width_range(1000, 2000)
        self.servo_params = ServoParams() #motor 
        initialize_servo(self.pi, self.servo_params)

    def set_actuator_postions(self, joint_angles):
        send_servo_commands(self.pi, self.servo_params, joint_angles)


#set servo's inital angle   (activate)
def initialize_servo(pi, servo_params):
    for leg_index in range(4):
        for axis_index in range(3):
            pi.servo[servo_params.pins[axis_index, leg_index]].angle = 90    
 
#set servo's angle
def send_servo_commands(pi, servo_params, joint_angles):
    for leg_index in range(4):
        for axis_index in range(3):
            angle = joint_angles[axis_index, leg_index]
            #angles = correction(angle, servo_params, axis_index, leg_index)
            if angle > 180:
                angle = angle%180
            elif angle < 0:
                angle = -angle
            pi.servo[servo_params.pins[axis_index, leg_index]].angle = angle


#set servo's initial angle  (not activate)
def deactivate_servos(pi, servo_params):
    for leg_index in range(4):
        for axis_index in range(3):
            pi.servo[servo_params.pins[axis_index, leg_index]].set_pulse_width_range()

#correction
def correction(angle, servo_params, axis_index, leg_index):
    angle_deviation = (
        angle - servo_params.neutral_angles[axis_index, leg_index]
    )
    pwm_value = (
        servo_params.neutral_angles[axis_index, leg_index]
        + servo_params.micros_per_rad * angle_deviation
    )
    return pwm_value