""" Per-robot configuration file that is 
particular to each individual robot, not 
just the type of robot. """
import numpy as np


#MICROS_PER_RAD = 9.259 * 180.0 / np.pi  # Must be calibrated

MICROS_PER_RAD = 8.37 * 180.0 / np.pi


NEUTRAL_ANGLE_DEGREES = np.array(
    [[7,  5,  13,  3], [61, 55, 39, 37], [41, 29, 44, 49]]
)

#a = [0, 2, 3, 4, 6, 8, 9, 10]  역방향
#b = [1, 5, 7, 11]  정방향
# 조립시 모터 값 0, 

PS4_COLOR = {"red": 0, "blue": 0, "green": 255}
PS4_DEACTIVATED_COLOR = {"red": 0, "blue": 0, "green": 50}
